package com.antonriva.backendSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
