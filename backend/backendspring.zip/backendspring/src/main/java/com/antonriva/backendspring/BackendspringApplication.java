package com.antonriva.backendspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendspringApplication.class, args);
	}

}
