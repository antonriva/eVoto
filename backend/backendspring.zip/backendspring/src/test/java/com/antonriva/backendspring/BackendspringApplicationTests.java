package com.antonriva.backendspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
